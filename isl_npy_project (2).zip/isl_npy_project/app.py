# app.py (Modified)

@app.route('/translate', methods=['POST'])
def translate():
    # 🚨 FIX 1: Change to read JSON data, not form data
    try:
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({'error': 'Missing text in request'}), 400
        text = data['text'].lower().strip()
    except Exception:
        return jsonify({'error': 'Invalid JSON format'}), 400

    # ... rest of your Flask logic is fine ...
    npy_file = SIGN_MAP.get(text)

    if not npy_file:
        # 🚨 FIX 2: Return a structure the JS can handle easily (success: false)
        return jsonify({'success': False, 'message': f"No ISL gesture found for '{text}'"}), 404

    path = os.path.join(app.root_path, 'static', 'npy', text, npy_file) # Adjusted path logic for clarity
    
    # ... your file existence check ...
    
    # Load hand keypoints from .npy file
    # ...
    
    return jsonify({'success': True, 'keypoints': data.tolist()}) # Add success status