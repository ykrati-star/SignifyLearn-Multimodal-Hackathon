// scripts.js (Rewritten)

document.addEventListener('DOMContentLoaded', () => {
    // Get the elements we need
    const btn = document.getElementById('generateBtn');
    const input = document.getElementById('textInput');
    const statusDiv = document.getElementById('status'); // Use the status div

    if (!btn || !input || !statusDiv) {
        console.error("Missing required HTML elements (generateBtn, textInput, or status).");
        return;
    }

    // Use event listener on the button/form
    btn.addEventListener('click', async (event) => {
        event.preventDefault(); // Stop the form from reloading the page

        const text = input.value.trim();
        if (!text) {
            statusDiv.textContent = "Enter some text!";
            return;
        }

        statusDiv.textContent = `Translating '${text}'...`;

        try {
            // 🚨 FIX 3.1: Change endpoint to match Flask
            const res = await fetch('/translate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: text }) // Send as JSON
            });

            const data = await res.json();
            
            // Handle server errors (404, 400, etc.)
            if (!res.ok || data.success === false) {
                statusDiv.textContent = `Translation failed: ${data.message || data.error || 'Unknown error'}`;
                return;
            }

            // 🚨 FIX 3.2: Pass the keypoints data to your 3D animation handler
            statusDiv.textContent = `Successfully loaded animation data for '${text}'. Starting animation...`;
            
            // Assuming your hand_animate.js file exposes a function like this:
            if (window.startHandAnimation) {
                 // The data.keypoints will be the array of frames from the .npy file
                 window.startHandAnimation(data.keypoints); 
            } else {
                 statusDiv.textContent = "Error: 3D animation function (startHandAnimation) not found in hand_animate.js";
            }

        } catch (error) {
            console.error('Fetch error:', error);
            statusDiv.textContent = `A network or processing error occurred: ${error.message}`;
        }
    });
});

// The drawGesture function needs to be replaced by 3D logic in hand_animate.js 
// (or integrated there, as you are using Three.js).