import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";

let scene, camera, renderer, hand;

function init() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.z = 2;

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.getElementById("hand-container").appendChild(renderer.domElement);

  const loader = new GLTFLoader();
  loader.load("/static/models/hand_rig.glb", (gltf) => {
    hand = gltf.scene;
    hand.scale.set(1.5, 1.5, 1.5);
    scene.add(hand);
    animate();
  });
}

function animate() {
  requestAnimationFrame(animate);
  if (hand) hand.rotation.y += 0.01;
  renderer.render(scene, camera);
}

init();
