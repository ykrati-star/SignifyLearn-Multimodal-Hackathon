let scene, camera, renderer, handPoints = [];

function init3D() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, 600/400, 0.1, 1000);
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(600, 400);
  document.getElementById('three-container').appendChild(renderer.domElement);

  const light = new THREE.PointLight(0xffffff);
  light.position.set(10, 10, 10);
  scene.add(light);

  camera.position.z = 2;
}

function animateHand(keypoints) {
  handPoints.forEach(p => scene.remove(p));
  handPoints = [];

  for (let i = 0; i < keypoints.length; i++) {
    const geom = new THREE.SphereGeometry(0.02);
    const mat = new THREE.MeshStandardMaterial({ color: 0x00ffcc });
    const sphere = new THREE.Mesh(geom, mat);
    const [x, y, z] = keypoints[i];
    sphere.position.set(x, -y, z);
    scene.add(sphere);
    handPoints.push(sphere);
  }

  renderer.render(scene, camera);
}

function animate() {
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
}

init3D();
animate();

document.getElementById('translateForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = document.getElementById('textInput').value;
  document.getElementById('status').textContent = "Processing...";

  const response = await fetch('/translate', {
    method: 'POST',
    body: new URLSearchParams({ text }),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });

  const data = await response.json();
  if (data.error) {
    document.getElementById('status').textContent = data.error;
  } else {
    document.getElementById('status').textContent = "✅ Gesture Loaded";
    animateHand(data.keypoints);
  }
});
